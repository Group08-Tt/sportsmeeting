# Lab3 Blog

[]()

(Blog link of the team leader⬆)

==Put the link on==

## Team Gathering

### Team Members

| Name | Skills | Programming Interests | Role | STU Number |
|--:|:---:|:---:|:---:|:---:|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|
|[Member]|[Skill]|[Interests]|[Role]|[STU Number]|

==Fill in the Form==

### Team Characteristics

(*Core Competitiveness*)

==Write something here==

### Team Logo

![team_logo](./team_logo.png)

==Need Picture==

### Our Photo

![photo](./team_photo.png)

Ten of us!

==Need Picture==

## Start Section

### Project Introduction

(*in one sentence*)
(*CN&EN*)

==Write something here==

### Criteria of individual contribution determination

### Individual Contribution

| Member | Proportion |
|:---:|:---:|
|[Member]|[Proportion]|
|[Member]|[Proportion]|
|[Member]|[Proportion]|
|[Member]|[Proportion]|
|[Member]|[Proportion]|
|[Member]|[Proportion]|
|[Member]|[Proportion]|
|[Member]|[Proportion]|
|[Member]|[Proportion]|
|[Member]|[Proportion]|
| Total | 100% |

(*It is forbidden to make the same score.*)

==Fill in the Form==

## Drip Record

(*点滴记录*)

### Mind Map

==Need Picture==

| Mind Maps |
|:---:|
|![Mind Map 1](./思维导图-导出_EN.png) |
|Record|
|![Mind Map 2](./思维导图2-导出.bdx_EN-导出.png) |
|About Client Side|
|![Mind Map 3](./思维导图3-导出.bdx_EN-导出.png) |
|About Management Side|

### Burnout Map

==Need Picture==

![image-20221203225407808](./burnout_map.png)

### UML

==Check this part carefully pls==

(x) Part XXXX
•	Person in charge: xxx
•	Description:
•	Problems faced by this part:
•	Problems solved:
•	XX design is applied to solve XX problem. One sentence description.
•	Attachment: 


![用例图](./用例图_EN.png)

![类图](./类图.jpg)

![类图1](./类图1.jpg)|

![entity relationship diagram](./未命名文件2-导出.bdx_EN-导出.png)

![image-20221203225616057](./image-20221203225616057.png)

![](./image-20221203225630773.png)

![](./image-20221203225557856.png)

![pic](./image-20221203225542962.png)

### Learning Progress Bar

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |

Member: [member]

| Week | New lines | Cumulative lines | Time spent on learning this week(hours) | Cumulative time spent on learning(hours) | Important growth |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | | | | | |
| 2 | | | | | |




### Experience

==Write something here==

## Video Clip

[Video on Bilibili.com]()

==Complete the link==

